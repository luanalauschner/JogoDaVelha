/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jogodavelha;


/**
 *
 * @author vilar
 */
public class Jogador {
    public String Jogador1;
    public String Jogador2;
    public String[][] matriz;

    public Jogador() {
        this.matriz = new String[3][3];
        this.Jogador1 = Jogador1;
        this.Jogador2 = Jogador2;
    }

    public String[][] getMatriz() {
        return matriz;
    }

    public void setMatriz(String[][] matriz) {
        this.matriz = matriz;
    }


    public String getJogador1() {
        return Jogador1;
    }

    public String getJogador2() {
        return Jogador2;
    }

    public void setJogador1(String Jogador1) {
        this.Jogador1 = Jogador1;
    }

    public void setJogador2(String Jogador2) {
        this.Jogador2 = Jogador2;
    }
    
    public static String AjeitaSimbolo(String Jogador){
        if(Jogador.length()==1){
            return Jogador;
        }
        else{
            char Primeirocaractere = Jogador.charAt(0);
            Jogador = Jogador.valueOf(Primeirocaractere);
            return Jogador;
        }
    }
    
    public String[][] Adiciona(int i, int j, String Jogo){
       
        if(VerificaSePode(matriz, i, j)){
            matriz[i][j] = Jogo;    
        }
        else{
            System.out.print("Escolha outra posição");
        }
        
        return matriz;
    }
    public static boolean VerificaSePode(String[][] matriz, int i, int j){
        return "?".equals(matriz[i][j]);
    }
    
    public static boolean VerificaSeGanhou(String[][] matriz, String Jogador){
        int ganhou1=0;
        for(int i=0; i<3; i++){
            for(int j=0; j<3; j++){
                if(matriz[i][j].equals(Jogador)){
                    ganhou1++;
                }
                if(ganhou1==3){
                    return true;
                }
            }
            ganhou1=0;
        }
        ganhou1=0;
        for(int j=0; j<3; j++){
            for(int i=0; i<3; i++){
                if(matriz[i][j].equals(Jogador)){
                    ganhou1++;
                }
                if(ganhou1==3){
                    return true;
                }
            }
            ganhou1=0;
        }
        ganhou1=0;
        for(int i=0; i<3; i++){
            if(matriz[i][i].equals(Jogador)){
                ganhou1++;
            }
        }
        if(ganhou1==3){
            return true;
        }
        ganhou1=0;
        int i = 0;
        int j = 2;
        while(i<3 && j>-1){
            if(matriz[i][j].equals(Jogador)){
                ganhou1++;
            }
            i++;
            j--;
        }
        return ganhou1==3;
    }
    
    public static void ImprimeMatriz(String[][] matriz){
        for(int i = 0; i < matriz.length; i++) {
            for(int k = 0; k < matriz.length; k++) {
                if(k!=2){
                System.out.print(matriz[i][k]+"|");    
                }
                else{
                    System.out.print(matriz[i][k]);
                }
               
            }
            if(i!=2){
                System.out.print("\n------");
            }
            System.out.print("\n");
        }
        System.out.print("\n\n\n\n");
    }
    public static boolean ehNumero(String coordenada){
        
        char[] ch = coordenada.toCharArray();
        return Character.isDigit(ch[0]);
        
    }

}
