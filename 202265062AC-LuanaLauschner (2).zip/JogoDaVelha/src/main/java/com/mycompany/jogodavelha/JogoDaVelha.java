/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.jogodavelha;
import static java.lang.Integer.parseInt;
import java.util.Scanner;

/**
 *
 * @author vilar
 */
public class JogoDaVelha {

    public static void main(String[] args) {
        System.out.println("=======================");
        System.out.println("===  JOGO DA VELHA  ===");
        System.out.println("=======================");
        
        Jogador j = new Jogador();
        Bot b = new Bot();
        Scanner teclado = new Scanner(System.in);
        for(int i = 0; i < j.matriz.length; i++) {
            for(int k = 0; k < j.matriz.length; k++) {
                j.matriz[i][k]="?";
            }
        }
        System.out.println("Vc quer jogar contra humano ou computador? Digite 1 para humano e 2 para computador.");
        int tipoDeJogo = teclado.nextInt();
        teclado.nextLine();
        
        
        if(tipoDeJogo==2){
            System.out.println("Qual simbolo o jogador 1 deseja usar?(Sera considerada apenas a primeira letra que o jogador digitar) ");
            j.Jogador1 = teclado.nextLine();
            j.Jogador1 = j.AjeitaSimbolo(j.Jogador1);
            b.bot = b.CriarSimbolo(b.bot, j);
            
            System.out.print("Jogador1: "+j.Jogador1+"\n"
            + "Bot: "+b.bot+"\n");
            
            int partida;
            for(partida = 0; partida<9; partida++){
                System.out.print("Jogador 1, digite as coordenadas do seu simbolo, no fomato x,y: ");
                String coord1;
                String[] c1;
                int x,y;
                
                while(true){
                    coord1 = teclado.nextLine();
                    c1 = coord1.split(",");
                    if(c1[0].matches("0")||c1[0].matches("1")||c1[0].matches("2")){
                        if(c1[1].matches("0")||c1[1].matches("1")||c1[1].matches("2")){
                            x = parseInt(c1[0]);
                            y = parseInt(c1[1]);
                            if(!j.VerificaSePode(j.matriz, x, y)){
                                System.out.print("Digite novamente as coordenadas, elas precisam estar disponiveis e ser entre 0 e 2 no formato x,y \n");
                                continue;
                            }
                            else{
                                break;
                            }
                        }
                        else{
                            System.out.print("Digite novamente as coordenadas, elas precisam estar disponiveis e ser entre 0 e 2 no formato x,y \n");
                            continue;
                        }
                        
                    }
                    else{
                        System.out.print("Digite novamente as coordenadas, elas precisam estar disponiveis e ser entre 0 e 2 no formato x,y \n");
                        continue;
                    }
                }
                j.matriz[x][y] = j.Jogador1;
                j.ImprimeMatriz(j.matriz);
                

                if(j.VerificaSeGanhou(j.matriz, j.Jogador1)){
                  System.out.print("Parabens Jogador1, voce ganhou!!");
                  break;
                }
                b.Vencer(b.bot, j);
                j.ImprimeMatriz(j.matriz);
                if(j.VerificaSeGanhou(j.matriz, b.bot)){
                    System.out.print("Poxa, parece que o bot ganhou :(");
                    break;
                }
            partida++;  
            }
            if(partida==9){
                System.out.print("Opa, parece que deu velha :(");
            }    
        }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////       
        if(tipoDeJogo==1){
            System.out.println("Qual simbolo o jogador 1 deseja usar?");
            j.setJogador1(teclado.nextLine());
            j.Jogador1 = j.AjeitaSimbolo(j.Jogador1);
            
            System.out.println("Qual simbolo o jogador 2 deseja usar?");
            j.setJogador2(teclado.nextLine());
            j.Jogador2 = j.AjeitaSimbolo(j.Jogador2);
            
            System.out.print("Jogador1: "+j.Jogador1+"\n"
            + "Jogador 2: "+j.Jogador2+"\n");
            while(j.Jogador1==j.Jogador2){
                System.out.println("Parece que vc escolheu o mesmo simbolo do jogador 1, por favor, ecolha . (Sera considerada apenas a primeira letra que o jogador digitar)");
                j.setJogador2(teclado.nextLine());
                j.AjeitaSimbolo(j.getJogador2());
            }
            int partida;    
            for(partida = 0; partida<9; partida++){
                System.out.print("Jogador 1, digite as ccoordenadas do seu simbolo, no fomato x,y: ");
                String coord1;
                String[] c1;
                int x,y;
                
                while(true){
                    coord1 = teclado.nextLine();
                    c1 = coord1.split(",");
                    if(c1[0].matches("0")||c1[0].matches("1")||c1[0].matches("2")){
                        if(c1[1].matches("0")||c1[1].matches("1")||c1[1].matches("2")){
                            x = parseInt(c1[0]);
                            y = parseInt(c1[1]);
                            if(!j.VerificaSePode(j.matriz, x, y)){
                                System.out.print("Digite novamente as coordenadas, elas precisam estar disponiveis e ser entre 0 e 2 no formato x,y /n");
                                continue;
                            }
                            else{
                                break;
                            }
                        }
                        else{
                            System.out.print("Digite novamente as coordenadas, elas precisam estar disponiveis e ser entre 0 e 2 no formato x,y /n");
                            continue;
                        }
                        
                    }
                    else{
                        System.out.print("Digite novamente as coordenadas, elas precisam estar disponiveis e ser entre 0 e 2 no formato x,y /n");
                        continue;
                    }
                }
                j.matriz[x][y] = j.Jogador1;
                j.ImprimeMatriz(j.matriz);
                

                if(j.VerificaSeGanhou(j.matriz, j.Jogador1)){
                  System.out.print("Parabens Jogador1, voce ganhou!!");
                  break;
                }
                
                System.out.print("Jogador 2, digite as coordenas do seu simbolo,  no fomato x,y: ");
                String coord2;
                String[] c2;
                int X,Y;
                
                while(true){
                    coord2 = teclado.nextLine();
                    c2 = coord2.split(",");
                    if(c2[0].matches("0")||c2[0].matches("1")||c2[0].matches("2")){
                        if(c2[1].matches("0")||c2[1].matches("1")||c2[1].matches("2")){
                            X = parseInt(c2[0]);
                            Y = parseInt(c2[1]);
                            if(!j.VerificaSePode(j.matriz, X, Y)){
                                System.out.print("Digite novamente as coordenadas, elas precisam estar disponiveis e ser entre 0 e 2 no formato x,y /n");
                                continue;
                            }
                            else{
                                break;
                            }
                        }
                        else{
                            System.out.print("Digite novamente as coordenadas, elas precisam estar disponiveis e ser entre 0 e 2 no formato x,y /n");
                            continue;
                        }
                        
                    }
                    else{
                        System.out.print("Digite novamente as coordenadas, elas precisam estar disponiveis e ser entre 0 e 2 no formato x,y /n");
                        continue;
                    }
                }
                j.matriz[X][Y] = j.Jogador2;
                j.ImprimeMatriz(j.matriz);
                
                if(j.VerificaSeGanhou(j.matriz, j.Jogador2)){
                    System.out.print("Parabens Jogador2, voce ganhou!!");
                    break;
                }
            partida++;    
            }
            if(partida==9){
                System.out.print("Opa, parece que deu velha :(");
            }
        }
    }
}
