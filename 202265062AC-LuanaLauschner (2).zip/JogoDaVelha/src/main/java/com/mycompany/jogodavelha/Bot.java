/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jogodavelha;

/**
 *
 * @author vilar
 */
public class Bot {
    public Jogador j;
    public String bot;

    public Bot() {
        this.j = j;
        this.bot = bot;
    }

    public Jogador getJ() {
        return j;
    }

    public String getBot() {
        return bot;
    }

    public void setJ(Jogador j) {
        this.j = j;
    }

    public void setBot(String bot) {
        this.bot = bot;
    }
    
    public String CriarSimbolo(String bot, Jogador j){
        if("X".equals(j.Jogador1)||"x".equals(j.Jogador1)){
            bot = "O";
        }
        else{
            bot = "X";
        }
        return bot;
    }
    public int Vencer(String Bot, Jogador j){
        int ganhar = 0;
        //GANHAR DIRETO!!!!!!!!!!
        //ganhar direto linha
        for(int i=0; i<3; i++){
            for(int k=0; k<3; k++){
                
               //considerar que está X|?|X
               if(k==2 && j.matriz[i][k].equals(Bot) && j.VerificaSePode(j.matriz, i, 1) && ganhar==1){
                  j.matriz[i][1] = bot; 
                  return 0;
               }
               if(j.matriz[i][k].equals(bot)){
                   ganhar++;
               }
               if(ganhar==2 && j.VerificaSePode(j.matriz, i, k)){
                   j.matriz[i][k] = bot;
                   return 0;
               }
            }
            ganhar=0;
        }
        ganhar=0;
        //ganhar direto coluna
        
        for(int k=0; k<3; k++){
            for(int i=0; i<3; i++){
               if(i==2 && j.matriz[i][k].equals(Bot) && j.VerificaSePode(j.matriz, 1, k) && ganhar==1){
                  j.matriz[i][1] = bot; 
                  return 0;
               }
               if(j.matriz[i][k].equals(bot)){
                   ganhar++;
               }
               if(ganhar==2 && j.VerificaSePode(j.matriz, i, k)){
                   j.matriz[i][k] = bot;
                   return 0;
               }
            }
            ganhar=0; 
        }
        ganhar=0;
        
        //ganhar diagonal principal
        for(int i=0; i<3; i++){
            if(j.matriz[i][i].equals(bot)){
                ganhar++;
            }
            if(ganhar==2 && j.VerificaSePode(j.matriz, i, i)){
                   j.matriz[i][i] = bot; ;
                   return 0;
            }            
        }
        
        //ganhar na outra diagonal       
        int i = 0;
        int k = 2;
        while(i<3 && k>-1){
            if(j.matriz[i][k].equals(bot)){
                ganhar++;
            }
            if(ganhar==2 && j.VerificaSePode(j.matriz, i, k)){
                   j.matriz[i][k] = bot;
                   return 0;
            }
            i++;
            k--;
        }
        //ATACAR JOGADOR!!!!!!!!!!!!
        int perder=0;
        //atacar direto linha
        for(i=0; i<3; i++){
            for(k=0; k<3; k++){
                
               //considerar que está X|?|X
               if(k==2 && j.matriz[i][k].equals(j.Jogador1) && j.VerificaSePode(j.matriz, i, 1) && perder==1){
                  j.matriz[i][1] = bot;  
                  return 0;
               }
               if(j.matriz[i][k].equals(j.Jogador1)){
                   perder++;
               }
               if(perder==2 && j.VerificaSePode(j.matriz, i, k)){
                   j.matriz[i][k] = bot; 
                   return 0;
               }
            }
            perder=0;
        }
        perder=0;
        //atacar direto coluna
        
        for(k=0; k<3; k++){
            for(i=0; i<3; i++){
               if(i==2 && j.matriz[i][k].equals(j.Jogador1) && j.VerificaSePode(j.matriz, 1, k) && ganhar==1){
                  j.matriz[i][1].equals(bot); 
                  return 0;
               }
               if(j.matriz[i][k].equals(j.Jogador1)){
                   perder++;
               }
               if(perder==2 && j.VerificaSePode(j.matriz, i, k)){
                   j.matriz[i][k] = bot; 
                   return 0;
               }
            }
            perder=0; 
        }
        perder=0;
        
        //atacar diagonal principal
        for(i=0; i<3; i++){
            if(j.matriz[i][i].equals(j.Jogador1)){
                perder++;
            }
            if(perder==2 && j.VerificaSePode(j.matriz, i, i)){
                   j.matriz[i][i] = bot; 
                   return 0;
            }            
        }
        
        //atacar na outra diagonal       
        i = 0;
        k = 2;
        while(i<3 && k>-1){
            if(j.matriz[i][k].equals(bot)){
                perder++;
            }
            if(perder==2 && j.VerificaSePode(j.matriz, i, k)){
                j.matriz[i][k] = bot; 
                return 0;
            }
            i++;
            k--;
        }        
        
        //Outros espaços
        for(i=0; i<3; i++){
            for(k=0; k<3; k++){
                if(j.VerificaSePode(j.matriz,i, k)){
                    j.matriz[i][k] = bot;
                    return 0;
                }
            }
        }
        return 0;
        }
    }

